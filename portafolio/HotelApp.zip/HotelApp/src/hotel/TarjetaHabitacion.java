package hotel;

import java.io.IOException;
import java.util.function.Consumer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;


public class TarjetaHabitacion extends VBox {

    // Elementos de tarjeta.fxml (se enlazan por el fx:id)
    @FXML
    private Label etiquetaNumero;
    @FXML
    private Label etiquetaEstado;
    @FXML
    private Label etiquetaTipo;
    @FXML
    private Label etiquetaPrecio;
    @FXML
    private Label etiquetaPlanta;
    @FXML
    private Label etiquetaCapacidad;
    @FXML
    private Label etiquetaVista;
    @FXML
    private Label etiquetaAccesible;
    @FXML
    private VBox zonaDetalles;
    @FXML
    private Button botonReservar;

    private Habitacion habitacion;
    private Consumer<Habitacion> alReservar;

    // Carga tarjeta.fxml y convierte esta clase en la raíz (el VBox) de ese FXML
    public TarjetaHabitacion() {
        FXMLLoader cargador = new FXMLLoader(getClass().getResource("tarjeta.fxml"));
        cargador.setRoot(this);
        cargador.setController(this);
        try {
            cargador.load();
        } catch (IOException ex) {
            throw new RuntimeException("No se pudo cargar tarjeta.fxml", ex);
        }
    }

    // Atajo: crea la tarjeta con todo configurado de una vez
    public TarjetaHabitacion(Habitacion habitacion, boolean compacta, Consumer<Habitacion> alReservar) {
        this();
        setHabitacion(habitacion);
        setCompacta(compacta);
        setAlReservar(alReservar);
    }

    // ---------- ENTRADAS ----------

    // Datos que muestra la tarjeta
    public void setHabitacion(Habitacion h) {
        this.habitacion = h;

        etiquetaNumero.setText("Habitación " + h.getNumero());
        etiquetaTipo.setText(h.getTipo());
        etiquetaPrecio.setText(String.format("%.0f € / noche", h.getPrecioNoche()));
        etiquetaPlanta.setText("Planta " + h.getPlanta());
        etiquetaCapacidad.setText("Capacidad: " + h.getCapacidad() + " persona(s)");
        etiquetaVista.setText("Vista: " + h.getVista());
        etiquetaAccesible.setText("Accesible: " + h.getAccesible());

        // Insignia de estado: el texto y el color (clase CSS) dependen del estado
        etiquetaEstado.setText(h.getEstadoTexto());
        etiquetaEstado.getStyleClass().removeAll("estado-disponible", "estado-ocupada", "estado-mantenimiento");
        etiquetaEstado.getStyleClass().add("estado-" + h.getEstado().toLowerCase());

        // Solo se puede reservar si está disponible
        botonReservar.setDisable(!h.estaDisponible());
        botonReservar.setText(h.estaDisponible() ? "Reservar" : "No disponible");
    }

    // Modo compacto: oculta los detalles (planta, capacidad, vista, accesible)
    public void setCompacta(boolean compacta) {
        zonaDetalles.setVisible(!compacta);
        zonaDetalles.setManaged(!compacta);
    }

    // ---------- SALIDA (evento) ----------

    // Quien use la tarjeta indica qué hacer cuando se pulsa "Reservar"
    public void setAlReservar(Consumer<Habitacion> alReservar) {
        this.alReservar = alReservar;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    // Se llama al pulsar el botón (onAction="#pulsarReservar" en tarjeta.fxml)
    @FXML
    private void pulsarReservar() {
        if (alReservar != null) {
            alReservar.accept(habitacion); // lanza el evento enviando la habitación
        }
    }
}
