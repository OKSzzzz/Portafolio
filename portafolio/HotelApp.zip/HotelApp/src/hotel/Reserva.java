package hotel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Representa una reserva (elemento <reserva> de reservas.xml).
 */
public class Reserva {

    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private String codigo;
    private String estado; // confirmada, pendiente, finalizada o cancelada
    private String cliente;
    private String email;
    private int habitacion;
    private LocalDate entrada;
    private LocalDate salida;
    private int personas;
    private String observaciones;

    public Reserva(String codigo, String estado, String cliente, String email, int habitacion,
                LocalDate entrada, LocalDate salida, int personas, String observaciones) {
        this.codigo = codigo;
        this.estado = estado;
        this.cliente = cliente;
        this.email = email;
        this.habitacion = habitacion;
        this.entrada = entrada;
        this.salida = salida;
        this.personas = personas;
        this.observaciones = observaciones;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getEstado() {
        return estado;
    }

    public String getCliente() {
        return cliente;
    }

    public String getEmail() {
        return email;
    }

    public int getHabitacion() {
        return habitacion;
    }

    public LocalDate getEntrada() {
        return entrada;
    }

    public LocalDate getSalida() {
        return salida;
    }

    public int getPersonas() {
        return personas;
    }

    public String getObservaciones() {
        return observaciones;
    }

    // Una reserva "activa" es la que bloquea la habitación (confirmada o pendiente)
    public boolean estaActiva() {
        return estado.equalsIgnoreCase("confirmada") || estado.equalsIgnoreCase("pendiente");
    }

    // Texto corto para mostrar en pantalla
    public String resumen() {
        return codigo + " · " + cliente + " · " + entrada.format(FORMATO) + " - "
                + salida.format(FORMATO) + " (" + estado + ")";
    }
}
