package hotel;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;

/**
 * Controlador de la ventana principal (vista.fxml).
 * Los elementos con @FXML se enlazan con los fx:id del archivo FXML.
 *
 * Tiene tres partes: menú, vistas Inicio / Habitaciones y vista Reservar.
 */
public class HotelController {

    // ================== ELEMENTOS DEL FXML ==================

    // ----- Cabecera y menú -----
    @FXML
    private Label subtituloHotel;
    @FXML
    private Button navInicio;
    @FXML
    private Button navHabitaciones;
    @FXML
    private Button navReservar;

    // ----- Las tres vistas -----
    @FXML
    private Node vistaInicio;
    @FXML
    private Node vistaHabitaciones;
    @FXML
    private Node vistaReservar;

    // ----- Vista Inicio -----
    @FXML
    private Label textoBienvenida;
    @FXML
    private Label textoDescripcion;
    @FXML
    private Label resDisponibles;
    @FXML
    private Label resOcupadas;
    @FXML
    private Label resMantenimiento;
    @FXML
    private FlowPane panelInicio;

    // ----- Vista Habitaciones -----
    @FXML
    private ComboBox<String> comboFiltro;
    @FXML
    private Label contadorHabitaciones;
    @FXML
    private FlowPane panelHabitaciones;

    // ----- Vista Reservar: búsqueda -----
    @FXML
    private ListView<String> listaHabitaciones;
    @FXML
    private TextField campoNumero;
    @FXML
    private Label etiquetaResultado;
    @FXML
    private Label valorTipo;
    @FXML
    private Label valorPlanta;
    @FXML
    private Label valorCapacidad;
    @FXML
    private Label valorPrecio;
    @FXML
    private Label valorVista;
    @FXML
    private Label valorAccesible;
    @FXML
    private Label valorEstado;
    @FXML
    private Label valorReserva;

    // ----- Vista Reservar: formulario -----
    @FXML
    private TextField campoNombre;
    @FXML
    private TextField campoEmail;
    @FXML
    private DatePicker fechaEntrada;
    @FXML
    private DatePicker fechaSalida;
    @FXML
    private ComboBox<String> comboPersonas;
    @FXML
    private Label etiquetaReserva;

    // Datos leídos del XML (los comparten las tres vistas)
    private HotelDatos datos;

    // Habitación que se ha buscado en la vista Reservar (null si no hay ninguna)
    private Habitacion habitacionActual = null;

    // ================== INICIO DE LA APLICACIÓN ==================

    // Se ejecuta automáticamente al cargar el FXML
    @FXML
    public void initialize() {
        comboPersonas.getItems().addAll("1", "2", "3", "4");
        comboPersonas.getSelectionModel().selectFirst();

        comboFiltro.getItems().addAll("Todas", "Disponible", "Ocupada", "Mantenimiento");
        comboFiltro.getSelectionModel().selectFirst();

        // 1) Leemos el XML
        try {
            datos = new HotelDatos();
        } catch (Exception ex) {
            subtituloHotel.setText("Error al leer reservas.xml");
            ex.printStackTrace();
            irInicio();
            return;
        }

        // 2) Rellenamos todas las vistas con esos datos
        subtituloHotel.setText(datos.getNombre() + " · " + datos.getCategoria() + " · " + datos.getCiudad());
        actualizarVistas();

        // 3) Eventos
        comboFiltro.setOnAction(e -> rellenarHabitaciones());

        // Al pulsar una habitación de la lista (vista Reservar), se busca automáticamente
        listaHabitaciones.getSelectionModel().selectedIndexProperty().addListener((obs, antes, ahora) -> {
            int i = ahora.intValue();
            if (i >= 0) {
                campoNumero.setText(String.valueOf(datos.getHabitaciones().get(i).getNumero()));
                buscarHabitacion();
            }
        });

        irInicio();
    }

    // Vuelve a dibujar todo con los datos actuales (se usa al arrancar y tras una reserva)
    private void actualizarVistas() {
        rellenarBienvenida();
        rellenarInicio();
        rellenarHabitaciones();
        refrescarLista();
    }

    // ================== MENÚ (cambiar de vista) ==================

    @FXML
    private void irInicio() {
        mostrarVista(vistaInicio, navInicio);
    }

    @FXML
    private void irHabitaciones() {
        mostrarVista(vistaHabitaciones, navHabitaciones);
    }

    @FXML
    private void irReservar() {
        mostrarVista(vistaReservar, navReservar);
    }

    // Enseña una vista, esconde las otras y marca el botón del menú activo
    private void mostrarVista(Node vista, Button botonActivo) {
        for (Node v : List.of(vistaInicio, vistaHabitaciones, vistaReservar)) {
            v.setVisible(v == vista);
            v.setManaged(v == vista);
        }
        for (Button b : List.of(navInicio, navHabitaciones, navReservar)) {
            b.getStyleClass().remove("nav-activo");
        }
        botonActivo.getStyleClass().add("nav-activo");
    }

    // ================== VISTAS INICIO Y HABITACIONES (usan el componente TarjetaHabitacion) ==================

    // ÚNICO sitio donde se crea una tarjeta: las dos vistas llaman a este método.
    // Cambian los DATOS (habitación) y el MODO (compacta o completa), pero el componente es el mismo.
    private TarjetaHabitacion crearTarjeta(Habitacion h, boolean compacta) {
        return new TarjetaHabitacion(h, compacta, this::reservarDesdeTarjeta);
    }

    // Respuesta al evento "reservar" de cualquier tarjeta, esté en la vista que esté
    private void reservarDesdeTarjeta(Habitacion h) {
        campoNumero.setText(String.valueOf(h.getNumero()));
        buscarHabitacion();
        irReservar();
    }

    // Texto de bienvenida y contadores de la vista Inicio
    private void rellenarBienvenida() {
        textoBienvenida.setText("Bienvenido al " + datos.getNombre());
        textoDescripcion.setText(datos.getCategoria() + " · " + datos.getDireccion()
                + " · Tel. " + datos.getTelefono());
        resDisponibles.setText(String.valueOf(datos.contar("disponible")));
        resOcupadas.setText(String.valueOf(datos.contar("ocupada")));
        resMantenimiento.setText(String.valueOf(datos.contar("mantenimiento")));
    }

    // VISTA INICIO: pocas tarjetas en modo COMPACTO (una disponible de cada tipo)
    private void rellenarInicio() {
        panelInicio.getChildren().clear();
        List<String> tiposVistos = new ArrayList<>();
        for (Habitacion h : datos.getHabitaciones()) {
            if (h.estaDisponible() && !tiposVistos.contains(h.getTipo())) {
                tiposVistos.add(h.getTipo());
                panelInicio.getChildren().add(crearTarjeta(h, true));
            }
        }
    }

    // VISTA HABITACIONES: todas las tarjetas en modo COMPLETO (con filtro por estado)
    private void rellenarHabitaciones() {
        String filtro = comboFiltro.getValue();
        int mostradas = 0;

        panelHabitaciones.getChildren().clear();
        for (Habitacion h : datos.getHabitaciones()) {
            boolean pasaFiltro = filtro == null || filtro.equals("Todas") || h.getEstado().equalsIgnoreCase(filtro);
            if (pasaFiltro) {
                panelHabitaciones.getChildren().add(crearTarjeta(h, false));
                mostradas++;
            }
        }
        contadorHabitaciones.setText(mostradas + " habitación(es)");
    }

    // ================== VISTA RESERVAR: PASO 1, BUSCAR ==================

    // Vuelve a escribir la lista de la izquierda con el estado actual
    private void refrescarLista() {
        List<String> filas = new ArrayList<>();
        for (Habitacion h : datos.getHabitaciones()) {
            filas.add(h.getNumero() + "  ·  " + h.getTipo() + "  ·  " + h.getEstadoTexto());
        }
        listaHabitaciones.getItems().setAll(filas);
    }

    // Se llama al pulsar "Buscar" (onAction="#buscarHabitacion" en el FXML)
    @FXML
    private void buscarHabitacion() {
        if (datos == null) {
            return;
        }
        etiquetaReserva.setText("");

        // 1) Comprobamos que se ha escrito un número válido
        int numero;
        try {
            numero = Integer.parseInt(campoNumero.getText().trim());
        } catch (NumberFormatException ex) {
            habitacionActual = null;
            borrarDatos();
            mostrar(etiquetaResultado, "Escribe un número de habitación válido.", "res-aviso");
            return;
        }

        // 2) Buscamos la habitación
        Habitacion h = datos.buscar(numero);

        // 3) Si no existe
        if (h == null) {
            habitacionActual = null;
            borrarDatos();
            mostrar(etiquetaResultado, "La habitación " + numero + " NO EXISTE.", "res-neutro");
            return;
        }

        // 4) Si existe, mostramos sus datos y su estado
        habitacionActual = h;
        mostrarDatos(h);

        if (h.estaDisponible()) {
            mostrar(etiquetaResultado, "La habitación " + numero + " está DISPONIBLE.", "res-ok");
        } else if (h.getEstado().equalsIgnoreCase("ocupada")) {
            mostrar(etiquetaResultado, "La habitación " + numero + " está OCUPADA.", "res-error");
        } else {
            mostrar(etiquetaResultado, "La habitación " + numero
                    + " está en MANTENIMIENTO (no se puede reservar).", "res-aviso");
        }
    }

    // Se llama al pulsar "Limpiar"
    @FXML
    private void limpiar() {
        habitacionActual = null;
        campoNumero.clear();
        campoNombre.clear();
        campoEmail.clear();
        fechaEntrada.setValue(null);
        fechaSalida.setValue(null);
        comboPersonas.getSelectionModel().selectFirst();
        listaHabitaciones.getSelectionModel().clearSelection();
        etiquetaReserva.setText("");
        borrarDatos();
        mostrar(etiquetaResultado, "Escribe un número y pulsa Buscar.", "res-neutro");
    }

    // ================== VISTA RESERVAR: PASO 2, RESERVAR ==================

    // Se llama al pulsar "Confirmar reserva"
    @FXML
    private void reservar() {
        if (datos == null) {
            return;
        }
        // Hay que haber buscado una habitación existente
        if (habitacionActual == null) {
            mostrar(etiquetaReserva, "Primero busca una habitación.", "res-aviso");
            return;
        }
        // Solo se puede reservar si está disponible
        if (!habitacionActual.estaDisponible()) {
            mostrar(etiquetaReserva, "La habitación " + habitacionActual.getNumero() + " está "
                    + habitacionActual.getEstado() + ". Elige otra.", "res-error");
            return;
        }

        // Comprobamos los datos del formulario
        String cliente = campoNombre.getText().trim();
        if (cliente.isEmpty()) {
            mostrar(etiquetaReserva, "Escribe el nombre del cliente.", "res-aviso");
            return;
        }
        String email = campoEmail.getText().trim();
        if (!email.contains("@")) {
            mostrar(etiquetaReserva, "Escribe un email válido.", "res-aviso");
            return;
        }

        LocalDate entrada = fechaEntrada.getValue();
        LocalDate salida = fechaSalida.getValue();
        if (entrada == null || salida == null) {
            mostrar(etiquetaReserva, "Elige la fecha de entrada y la de salida.", "res-aviso");
            return;
        }
        if (entrada.isBefore(LocalDate.now())) {
            mostrar(etiquetaReserva, "La fecha de entrada no puede ser pasada.", "res-aviso");
            return;
        }
        if (!salida.isAfter(entrada)) {
            mostrar(etiquetaReserva, "La salida debe ser posterior a la entrada.", "res-aviso");
            return;
        }

        int personas = Integer.parseInt(comboPersonas.getValue());
        if (personas > habitacionActual.getCapacidad()) {
            mostrar(etiquetaReserva, "Esta habitación admite como máximo "
                    + habitacionActual.getCapacidad() + " persona(s).", "res-aviso");
            return;
        }

        // Comprobamos que no choque con otra reserva de esa habitación
        for (Reserva r : datos.getReservas()) {
            if (r.getHabitacion() == habitacionActual.getNumero() && r.estaActiva()
                    && entrada.isBefore(r.getSalida()) && salida.isAfter(r.getEntrada())) {
                mostrar(etiquetaReserva, "Ya existe la reserva " + r.getCodigo()
                        + " en esas fechas. Cambia las fechas.", "res-error");
                return;
            }
        }

        // Todo correcto: creamos la reserva (solo en memoria)
        String codigo = "R" + String.format("%03d", datos.getReservas().size() + 1);
        datos.getReservas().add(new Reserva(codigo, "confirmada", cliente, email,
                habitacionActual.getNumero(), entrada, salida, personas,
                "Reserva realizada desde la aplicación"));
        habitacionActual.setEstado("ocupada");

        long noches = ChronoUnit.DAYS.between(entrada, salida);
        double total = noches * habitacionActual.getPrecioNoche();

        // Las tres vistas se actualizan (las tarjetas pasan a "Ocupada")
        actualizarVistas();
        mostrarDatos(habitacionActual);
        mostrar(etiquetaResultado, "La habitación " + habitacionActual.getNumero() + " está OCUPADA.", "res-error");
        mostrar(etiquetaReserva, "Reserva " + codigo + " confirmada: " + noches + " noche(s). Total: "
                + String.format("%.2f", total) + " €", "res-ok");
    }

    // ================== AYUDAS ==================

    private void mostrarDatos(Habitacion h) {
        valorTipo.setText(h.getTipo());
        valorPlanta.setText(String.valueOf(h.getPlanta()));
        valorCapacidad.setText(h.getCapacidad() + " persona(s)");
        valorPrecio.setText(String.format("%.2f € / noche", h.getPrecioNoche()));
        valorVista.setText(h.getVista());
        valorAccesible.setText(h.getAccesible());
        valorEstado.setText(h.getEstadoTexto());

        Reserva r = datos.reservaActiva(h.getNumero());
        valorReserva.setText(r == null ? "Sin reservas activas" : r.resumen());
    }

    private void borrarDatos() {
        valorTipo.setText("-");
        valorPlanta.setText("-");
        valorCapacidad.setText("-");
        valorPrecio.setText("-");
        valorVista.setText("-");
        valorAccesible.setText("-");
        valorEstado.setText("-");
        valorReserva.setText("-");
    }

    // Escribe un mensaje en un Label y le pone un color (clase CSS)
    private void mostrar(Label etiqueta, String mensaje, String claseCss) {
        etiqueta.getStyleClass().removeAll("res-neutro", "res-ok", "res-error", "res-aviso");
        etiqueta.getStyleClass().add(claseCss);
        etiqueta.setText(mensaje);
    }
}
