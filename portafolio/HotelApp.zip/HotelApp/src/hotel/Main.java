package hotel;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Clase principal. Ejecuta este archivo para abrir la interfaz.
 */
public class Main extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Carga la interfaz definida en el archivo FXML
        Parent raiz = FXMLLoader.load(getClass().getResource("vista.fxml"));

        Scene escena = new Scene(raiz, 1000, 840);
        stage.setTitle("HotelApp - Sistema de reservas");
        stage.setScene(escena);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
