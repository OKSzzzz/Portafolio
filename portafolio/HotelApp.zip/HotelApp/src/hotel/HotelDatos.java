package hotel;

import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Lee reservas.xml UNA sola vez y guarda los datos del hotel, las habitaciones y las reservas.
 * Todas las vistas (Inicio, Habitaciones y Reservar) usan esta misma clase,
 * así los datos son siempre los mismos en todas las pantallas.
 */
public class HotelDatos {

    private String nombre;
    private String categoria;
    private String ciudad;
    private String direccion;
    private String telefono;

    private final List<Habitacion> habitaciones = new ArrayList<>();
    private final List<Reserva> reservas = new ArrayList<>();

    // Al crear el objeto se lee el XML. Si falla, lanza una excepción.
    public HotelDatos() throws Exception {
        InputStream archivo = getClass().getResourceAsStream("reservas.xml");
        DocumentBuilder lector = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document documento = lector.parse(archivo);

        // Datos del hotel
        Element hotel = documento.getDocumentElement();
        nombre = hotel.getAttribute("nombre");
        categoria = hotel.getAttribute("categoria");
        ciudad = texto(hotel, "ciudad");
        direccion = texto(hotel, "direccion");
        telefono = texto(hotel, "telefono");

        // Habitaciones: numero, estado y planta están en atributos
        NodeList nodosHab = documento.getElementsByTagName("habitacion");
        for (int i = 0; i < nodosHab.getLength(); i++) {
            Element e = (Element) nodosHab.item(i);
            habitaciones.add(new Habitacion(
                    Integer.parseInt(e.getAttribute("numero")),
                    e.getAttribute("estado"),
                    Integer.parseInt(e.getAttribute("planta")),
                    texto(e, "tipo"),
                    Integer.parseInt(texto(e, "capacidad")),
                    Double.parseDouble(texto(e, "precioNoche")),
                    texto(e, "vista"),
                    texto(e, "accesible")));
        }

        // Reservas
        NodeList nodosRes = documento.getElementsByTagName("reserva");
        for (int i = 0; i < nodosRes.getLength(); i++) {
            Element e = (Element) nodosRes.item(i);
            reservas.add(new Reserva(
                    e.getAttribute("codigo"),
                    e.getAttribute("estado"),
                    texto(e, "nombre") + " " + texto(e, "apellidos"),
                    texto(e, "email"),
                    Integer.parseInt(texto(e, "habitacionReservada")),
                    LocalDate.parse(texto(e, "entrada")),
                    LocalDate.parse(texto(e, "salida")),
                    Integer.parseInt(texto(e, "personas")),
                    texto(e, "observaciones")));
        }
    }

    // Devuelve el texto de una etiqueta hija (por ejemplo <tipo>Doble</tipo>)
    private static String texto(Element padre, String etiqueta) {
        return padre.getElementsByTagName(etiqueta).item(0).getTextContent().trim();
    }

    // ----- Datos del hotel -----
    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    // ----- Listas -----
    public List<Habitacion> getHabitaciones() {
        return habitaciones;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    // ----- Consultas -----

    // Devuelve la habitación con ese número, o null si no existe
    public Habitacion buscar(int numero) {
        for (Habitacion h : habitaciones) {
            if (h.getNumero() == numero) {
                return h;
            }
        }
        return null;
    }

    // Devuelve la reserva confirmada o pendiente de una habitación, o null si no tiene
    public Reserva reservaActiva(int numeroHabitacion) {
        for (Reserva r : reservas) {
            if (r.getHabitacion() == numeroHabitacion && r.estaActiva()) {
                return r;
            }
        }
        return null;
    }

    // Cuenta cuántas habitaciones hay en un estado (disponible, ocupada o mantenimiento)
    public int contar(String estado) {
        int total = 0;
        for (Habitacion h : habitaciones) {
            if (h.getEstado().equalsIgnoreCase(estado)) {
                total++;
            }
        }
        return total;
    }
}
