package hotel;

/**
 * Representa una habitación del hotel (elemento <habitacion> de reservas.xml).
 */
public class Habitacion {

    private int numero;
    private String estado; // disponible, ocupada o mantenimiento
    private int planta;
    private String tipo;
    private int capacidad;
    private double precioNoche;
    private String vista;
    private String accesible;

    public Habitacion(int numero, String estado, int planta, String tipo, int capacidad,
                      double precioNoche, String vista, String accesible) {
        this.numero = numero;
        this.estado = estado;
        this.planta = planta;
        this.tipo = tipo;
        this.capacidad = capacidad;
        this.precioNoche = precioNoche;
        this.vista = vista;
        this.accesible = accesible;
    }

    public int getNumero() {
        return numero;
    }

    public String getEstado() {
        return estado;
    }

    public int getPlanta() {
        return planta;
    }

    public String getTipo() {
        return tipo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public double getPrecioNoche() {
        return precioNoche;
    }

    public String getVista() {
        return vista;
    }

    public String getAccesible() {
        return accesible;
    }

    // Se usa al confirmar una reserva (la habitación pasa a "ocupada")
    public void setEstado(String estado) {
        this.estado = estado;
    }

    public boolean estaDisponible() {
        return estado.equalsIgnoreCase("disponible");
    }

    // Estado con la primera letra en mayúscula, para mostrarlo en pantalla
    public String getEstadoTexto() {
        return estado.substring(0, 1).toUpperCase() + estado.substring(1);
    }
}
